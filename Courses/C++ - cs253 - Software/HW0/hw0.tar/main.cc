#include <iostream>
using namespace std;

        int main() {
            // How many CU students does it take to change a light bulb?
            cout << "Zero, they pay someone else to do it.\n";
	      return 0;

}