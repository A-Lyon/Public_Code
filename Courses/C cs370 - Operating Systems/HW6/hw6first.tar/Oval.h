#ifndef OVAL_H_INCLUDED
#define OVAL_H_INCLUDED

#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>
#include <vector>
#include <iterator>
 
template <typename T, int shift = 1, typename C = std::equal_to<T>>
class Oval{

    //using super = vector<T>;

    public:
        //using typename vector::iterator, vector::begin, vector::end, vector::clear;
        
    std::vector<T> oval;

        //Ctor
    Oval () = default;

        //Copy CTorr
    Oval (const Oval& O) = default;

        //open ended copy ctor
        //std::vector<T>::const_iterator start, std::vector<T>::const_iterator end

    template <typename Iter>
    Oval (Iter start, Iter end){
        //T std::vector<T>::iterator my_iterator;
        while (start != end){
            oval.push_back(*start++);
        }   

    }

        //Assignment Operator
    Oval& operator= (const Oval&) = default;

        //Dtor
    ~Oval () = default;


        //Return the number of data items currently stored.
    size_t size() const{
        return oval.size();
    }

    const T& operator[] (size_t i) const{
        return oval[i];
    }

    void clear(){
        oval.clear;
    }

        //Erase all matching items, returns number of items erased.
    size_t erase(const T& e_me){
        int num = 0;

        for(int i = 0; i < oval.size(); i++){
            if(oval.find(e_me) != -1){
                oval.erase(oval.find(e_me));
                num++;
            }
        }
        return num;
    }


        //use std's equal_to
    //std::equal_to<typename T> = default;

        //Look for the first instance of the given value from the start of the list to the end. 
        //Return the index of the item (the first item is 0) after that value was moved forward
        // (toward the start of the container, toward the first item). 
        //If the item is already too far forward, move it as far as you can to the first location.
        // Return −1 if not found.
    int find(const T& other){
        for (int i = 0; i < oval.size; i++){
            if(oval[i].equal_to(other)){
                if((i - shift) > 0){
                    T temp = oval[i];
                    oval[i] = oval[i - shift];
                    oval[i - shift] = temp;
                }
                return i;
            }
        }
        return -1;
    }   
    /*

size_t count(const value_type &) const
Return how many times the given value occurs in the container.
push_back
Works the same as vector’s push_back(). Duplicates are not treated specially.







Make it have no values.




const value_type & operator[](size_t) const
Subscripting. [0] returns a reference to the first element, [1] returns a reference to the second element, etc. Results are undefined if the subscript is out of range.
Const-correctness, for arguments, methods, and operators, is your job. For example, it must be possible to call .count() on a const object, or to copy a const object to a non-const object.                 

Don’t forget to use the comparison functor for .find(), .count(), and .erase(). Using simple == is not correct.           


    */

        //private: 
    
    

};

/*

vectors index oval[i] or Oval(i)
stretchy, use oval.push_back



*/


#endif