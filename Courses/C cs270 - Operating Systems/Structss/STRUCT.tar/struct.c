/* CS270 
 *
 * Author: Eric Martin
 * Date:   6/29/2021
 */
 
#include "struct.h"
#include <stdio.h>
#include <stdlib.h>

/********** FUNCTION DEFINITIONS ***********************************************/

void readStudentAndEnroll(Student **slot)
{

  Student * newStudent = (Student *)malloc(sizeof(Student));

  scanf( "%s", (newStudent->firstName));
  scanf( "%f",&(newStudent->qualityPoints));
  scanf( "%d", &(newStudent->numCredits));
 
  *slot = newStudent; 
  
  //free(newStudent);
}

void displayStudent(Student s)
{
  float GPA = s.qualityPoints / s.numCredits;
  //printf("quality = %1f\n\n", s.qualityPoints);
  //printf("numCredits = %d\n\n", s.numCredits);

  printf("%s, %0.2f\n", s.firstName, GPA);


}
