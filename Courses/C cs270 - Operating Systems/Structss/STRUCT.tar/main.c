 /** @mainpage 
   *  \htmlinclude "STRUCTS.html"
   */
/* CS270 
 *
 * Author: Eric Martin
 * Date:   6/29/2021
 */
#include<stdio.h>
#include <stdlib.h>
#include "struct.h"

int main(int argc, const char **argv)
{

  int inputNumStudents; 
  scanf( "%d", &inputNumStudents); 
  //printf("input num students = %d\n", inputNumStudents);
  ClassRoster roster;
  Student student;

  roster.numStudents = inputNumStudents;
  roster.students = (Student**)calloc(roster.numStudents ,  sizeof(student));

   
  for(int i = 0; i < roster.numStudents; i++){
	readStudentAndEnroll(&roster.students[i]);
  }

  for(int i = 0; i < roster.numStudents; i++){
	displayStudent(*roster.students[i]);
        free(roster.students[i]);
  }

  free(roster.students);


  return 0;
}
